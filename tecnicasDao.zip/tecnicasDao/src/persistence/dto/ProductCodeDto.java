package persistence.dto;

/**
 * Created by ljunior on 4/14/16.
 */
public class ProductCodeDto {
    private String productCode;
    private String discountCode;
    private String description;

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return productCode + " - " + discountCode + " | " + description;
    }
}
