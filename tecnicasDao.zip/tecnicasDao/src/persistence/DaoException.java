package persistence;

/**
 * Created by ljunior on 4/14/16.
 */
public class DaoException extends Exception {
}
